// Firebase SDK Imports

import { initializeApp }
from "https://www.gstatic.com/firebasejs/11.9.1/firebase-app.js";

import { getAuth }
from "https://www.gstatic.com/firebasejs/11.9.1/firebase-auth.js";

import { getFirestore }
from "https://www.gstatic.com/firebasejs/11.9.1/firebase-firestore.js";

import { getStorage }
from "https://www.gstatic.com/firebasejs/11.9.1/firebase-storage.js";


// Firebase Configuration

const firebaseConfig = {

    apiKey:
    "YOUR_API_KEY",

    authDomain:
    "mintsnot.firebaseapp.com",

    projectId:
    "mintsnot",

    storageBucket:
    "mintsnot.firebasestorage.app",

    messagingSenderId:
    "405561152073",

    appId:
    "1:405561152073:web:d5cf2f883b237b2eaae598",

    databaseURL:
    "https://mintsnot-default-rtdb.firebaseio.com",

    measurementId:
    "G-0P06756TCX"

};


// Initialize Firebase

const app =
initializeApp(firebaseConfig);


// Services

const auth =
getAuth(app);

const db =
getFirestore(app);

const storage =
getStorage(app);


// Export Services

export {

    auth,

    db,

    storage

};