// ===============================
// MOBILE MENU TOGGLE
// ===============================

const menuToggle =
document.querySelector(".menu-toggle");

const navMenu =
document.querySelector("nav ul");

if(menuToggle){

    menuToggle.addEventListener(
        "click",
        () => {

            navMenu.classList.toggle(
                "show"
            );

        }
    );

}


// ===============================
// ACTIVE NAVIGATION LINK
// ===============================

const currentPage =
window.location.pathname
.split("/")
.pop();

const links =
document.querySelectorAll(
    "nav ul li a"
);

links.forEach(link => {

    const href =
    link.getAttribute("href");

    if(href === currentPage){

        link.classList.add(
            "active"
        );

    }

});


// ===============================
// SMOOTH SCROLL
// ===============================

document.querySelectorAll(
    'a[href^="#"]'
).forEach(anchor => {

    anchor.addEventListener(
        "click",
        function(e){

            e.preventDefault();

            const target =
            document.querySelector(
                this.getAttribute(
                    "href"
                )
            );

            if(target){

                target.scrollIntoView({

                    behavior:
                    "smooth"

                });

            }

        }
    );

});


// ===============================
// SCROLL TO TOP BUTTON
// ===============================

const topButton =
document.createElement(
    "button"
);

topButton.innerHTML = "↑";

topButton.id =
"topBtn";

document.body.appendChild(
    topButton
);

window.addEventListener(
    "scroll",
    () => {

        if(

            document
            .documentElement
            .scrollTop > 300

        ){

            topButton.style.display =
            "block";

        }else{

            topButton.style.display =
            "none";

        }

    }
);

topButton.addEventListener(
    "click",
    () => {

        window.scrollTo({

            top:0,

            behavior:
            "smooth"

        });

    }
);


// ===============================
// PAGE LOADED
// ===============================

window.addEventListener(
    "load",
    () => {

        console.log(

            "Felege Tibeb Website Loaded"

        );

    }
);